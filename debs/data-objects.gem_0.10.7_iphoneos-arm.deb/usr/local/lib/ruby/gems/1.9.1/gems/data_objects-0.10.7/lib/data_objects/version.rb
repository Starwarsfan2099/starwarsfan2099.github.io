module DataObjects
  VERSION = '0.10.7'
end
