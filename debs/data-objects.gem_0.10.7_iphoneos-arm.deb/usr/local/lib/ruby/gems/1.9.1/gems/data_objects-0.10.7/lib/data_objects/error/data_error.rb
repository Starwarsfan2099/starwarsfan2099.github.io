module DataObjects
  class DataError < SQLError
  end
end
