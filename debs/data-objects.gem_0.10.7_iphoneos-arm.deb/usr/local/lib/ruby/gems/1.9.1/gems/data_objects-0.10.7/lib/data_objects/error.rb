module DataObjects
  class Error < StandardError
  end
end
