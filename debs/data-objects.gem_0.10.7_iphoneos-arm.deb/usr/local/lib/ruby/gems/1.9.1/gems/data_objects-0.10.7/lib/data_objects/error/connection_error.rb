module DataObjects
  class ConnectionError < SQLError
  end
end
