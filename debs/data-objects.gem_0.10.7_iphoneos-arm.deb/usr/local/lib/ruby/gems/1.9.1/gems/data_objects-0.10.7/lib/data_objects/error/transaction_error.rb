module DataObjects
  class TransactionError < SQLError
  end
end
