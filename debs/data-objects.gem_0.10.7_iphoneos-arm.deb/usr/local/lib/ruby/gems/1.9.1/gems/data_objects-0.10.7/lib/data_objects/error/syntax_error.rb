module DataObjects
  class SyntaxError < SQLError
  end
end
