module DataObjects
  class IntegrityError < SQLError
  end
end
