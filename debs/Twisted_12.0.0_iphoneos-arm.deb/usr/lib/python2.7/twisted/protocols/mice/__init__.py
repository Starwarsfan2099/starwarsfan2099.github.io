"""Mice Protocols."""
