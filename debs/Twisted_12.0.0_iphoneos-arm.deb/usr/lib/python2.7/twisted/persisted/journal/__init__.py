# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Command-journalling persistence framework inspired by Prevayler.

This package is deprecated since Twisted 11.0.

Maintainer: Itamar Shtull-Trauring
"""

