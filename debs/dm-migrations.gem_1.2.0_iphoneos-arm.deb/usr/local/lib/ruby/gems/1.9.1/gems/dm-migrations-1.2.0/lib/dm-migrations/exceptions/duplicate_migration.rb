module DataMapper
  module Migrations
    class DuplicateMigration < StandardError
    end
  end
end
