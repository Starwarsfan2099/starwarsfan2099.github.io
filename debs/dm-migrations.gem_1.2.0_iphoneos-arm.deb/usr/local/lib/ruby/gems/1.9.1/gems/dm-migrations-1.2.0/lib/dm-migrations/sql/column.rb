module SQL
  class Column
    attr_accessor :name, :type, :not_null, :default_value, :primary_key, :unique
  end
end
