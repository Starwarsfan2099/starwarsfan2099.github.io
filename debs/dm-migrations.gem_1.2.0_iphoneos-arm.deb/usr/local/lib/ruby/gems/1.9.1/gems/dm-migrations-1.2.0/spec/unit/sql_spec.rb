require 'spec_helper'

describe 'SQL module' do

  it 'doesnt really do anything'

end
