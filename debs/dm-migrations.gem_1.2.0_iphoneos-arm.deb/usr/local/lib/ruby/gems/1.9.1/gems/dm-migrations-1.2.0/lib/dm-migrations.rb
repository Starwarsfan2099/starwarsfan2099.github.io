require 'dm-core'
require 'dm-migrations/migration'
require 'dm-migrations/auto_migration'
