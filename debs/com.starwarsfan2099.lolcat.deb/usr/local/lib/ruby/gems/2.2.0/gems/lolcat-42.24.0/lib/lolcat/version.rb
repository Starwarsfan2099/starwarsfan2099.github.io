module Lolcat
  VERSION = "42.24.0"
end
