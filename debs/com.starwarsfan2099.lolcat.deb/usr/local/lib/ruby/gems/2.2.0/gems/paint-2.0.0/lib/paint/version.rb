module Paint
  VERSION = '2.0.0'.freeze
end
