module DataObjects
  module Sqlite3
    VERSION = '0.10.7'
  end
end
