module MessagePack
	VERSION = "0.4.6"
end
