require 'msfrpc-client/client'

