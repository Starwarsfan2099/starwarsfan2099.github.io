module DataMapper
  VERSION = '1.2.0.rc1'
end
