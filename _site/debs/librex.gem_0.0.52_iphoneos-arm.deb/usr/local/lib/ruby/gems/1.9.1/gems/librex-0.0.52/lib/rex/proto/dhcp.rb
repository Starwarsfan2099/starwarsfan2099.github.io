# $Id: dhcp.rb 12196 2011-04-01 00:51:33Z egypt $
#
# DHCP Server support written by scriptjunkie
#

require 'rex/proto/dhcp/constants'
require 'rex/proto/dhcp/server'
