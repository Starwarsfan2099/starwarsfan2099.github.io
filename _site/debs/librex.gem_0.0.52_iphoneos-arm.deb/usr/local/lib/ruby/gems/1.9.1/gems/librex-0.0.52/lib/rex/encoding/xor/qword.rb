#!/usr/bin/env ruby

require 'rex/encoding/xor/generic'

module Rex
module Encoding
module Xor

class Qword < Generic

	def Qword.keysize
		8
	end

end end end end