require 'rex/proto/http'
require 'rex/proto/smb'
require 'rex/proto/ntlm'
require 'rex/proto/dcerpc'
require 'rex/proto/drda'
require 'rex/proto/iax2'

module Rex
module Proto

attr_accessor :alias

end
end
