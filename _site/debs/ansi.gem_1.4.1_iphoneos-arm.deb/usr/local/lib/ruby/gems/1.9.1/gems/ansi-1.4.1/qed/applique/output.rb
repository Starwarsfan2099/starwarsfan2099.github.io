When "output will be" do |text|
  # how to get result of last block?
  @_.strip.assert == text.strip
end

