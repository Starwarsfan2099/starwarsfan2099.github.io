require 'dm-sqlite-adapter/adapter'
